﻿//{{NO_DEPENDENCIES}}
// Включаемый файл, созданный в Microsoft Visual C++.
// Используется в UstinovaOOPP3.rc
//
#define IDD_ABOUTBOX				100
#define IDR_MAINFRAME				128
#define IDR_UstinovaOOPP3TYPE				130

// Следующие стандартные значения для новых объектов
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE	310
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		310
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
